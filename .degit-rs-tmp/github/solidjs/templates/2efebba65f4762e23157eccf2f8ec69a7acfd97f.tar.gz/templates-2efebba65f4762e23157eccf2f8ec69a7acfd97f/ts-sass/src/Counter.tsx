export default function Counter() {
  return <h1>Hello world</h1>;
}
